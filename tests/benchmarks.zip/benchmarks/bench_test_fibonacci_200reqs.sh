folder="test_fibonacci_200reqs"
mkdir ./${folder}

echo "Benchmark $folder starting..."

for ((client=1; client<=20; client++))
do
    for ((req=1; req<=10; req++))
    do
    		echo "client: $client; req: $req"
        (time curl -m 300 -F file=@fibonacci.zip https://ba-serverless-testing-t6e6p4w6oa-ew.a.run.app/test/gradle) > ./${folder}/out.${client}.${req}.txt 2>&1 &
    done
    sleep 1 #second
done
wait
echo "------"

echo "Calculating avg..."
total_calls=0
total_success=0
total_t=0
failed=""
for file in ./${folder}/*
do
	total_calls=$((total_calls + 1))

	success=$(grep "BUILD SUCCESSFUL" "$file")
	success_len=${#success}
	if ((success_len > 0)); then
		total_success=$((total_success + 1))

		t=$(grep "real\\t" "$file")

		# Get time parts (assumeing max req time < 10min)
		t=${t:(-9)}
		t=${t:0:8}	# clear the s char
		
		idx=(-1)
		if [[ ${t:0:1} == 0 ]]; then
			idx=0
		else
			idx=1
		fi
		
		min=${t:$idx:1}
		min_to_sec=$((min * 60))
		total_t=$(python -c "import sys; print(float(sys.argv[1])+float(sys.argv[2]))" $total_t $min_to_sec)

		idx=$((idx + 2))
		sec=${t:$idx}
		total_t=$(python -c "import sys; print(float(sys.argv[1])+float(sys.argv[2]))" $total_t $sec)
	fi
done

echo "Success: $total_success out of $total_calls calls"
echo "Total:\\t${total_t}s"

avg=$(python -c "import sys; print(float(sys.argv[1]) / float(sys.argv[2]))" $total_t $total_success)
echo "Avg:\\t${avg}s"
