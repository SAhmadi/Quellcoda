This file was created manually, using the scripts and their output.
It gives a visual overview of the benchmarks.

BEFORE starting one of the request-scripts with: `./<script_name>.sh`
please remove, rename or move the associated folder
(the folder with the same name but without the "bench" prefix).
Please only execute one script at a time.
The scripts will call the appropriate endpoint with the needed java/zip files
as a payload. At the end of each scipt a few useful informations will be
printed.

BEFORE starting one of the `bench_calc_avg` scripts,
open the scripts and manually change the variable `total_success`
to the amount of successful responses to include in the calculation.
But makes sure the number is <= than the number of successful responses
in the associated folder.

*****************************************
* 500 CALLS: /run/gradle and /test/gradle
*****************************************
run_hello_world_500reqs
-----------------------
Success: 453 out of 500 calls
Total:	9375.638s
Avg:	20.6967726269s

test_hello_world_500reqs
------------------------
Success: 60 out of 500 calls
Total:	1574.507s
Avg:	26.2417833333s

run_fibonacci_500reqs
--------------------
Success: 481 out of 500 calls
Total:	12024.402s
Avg:	24.9987567568s

test_fibonacci_500reqs
----------------------
Success: 68 out of 500 calls
Total:	1897.38s
Avg:	27.9026470588s


*****************************************
* 200 CALLS: /run/gradle and /test/gradle
*****************************************
test_hello_world_200reqs
------------------------
Success: 135 out of 200 calls
Total:	3778.675s
Avg:	27.9901851852s

run_hello_world_200reqs
-----------------------
Success: 192 out of 200 calls
Total:	5175.862s
Avg:	26.9576145833s

run_fibonacci_200reqs
---------------------
Success: 191 out of 200 calls
Total:	4727.391s
Avg:	24.7507382199s

test_fibonacci_200reqs
----------------------
Success: 95 out of 200 calls
Total:	2713.621s
Avg:	28.5644315789s


*****************************************
* 200 CALLS: /run/java and /test/java
*****************************************
run_calculator_200reqs
-----------------------
Success: 200 out of 200 calls
Total:	3608.541s
Avg:	18.042705s

test_calculator_200reqs
-----------------------
Success: 200 out of 200 calls
Total:	2855.684s
Avg:	14.27842s

*****************************************
* 500 CALLS: /run/java and /test/java
*****************************************
run_calculator_500reqs
-----------------------
Success: 500 out of 500 calls
Total:	9059.6s
Avg:	18.1192s

test_calculator_500reqs
-----------------------
Success: 500 out of 500 calls
Total:	10748.206s
Avg:	21.496412s


**********************************************
* Average response time of successful requests
**********************************************
Hello World /run/gradle
Avg response time of the 450 requests: 20.66562s
----
Hello World /test/gradle
Avg response time of the 60 requests:	26.2417833333s
----
Fibonacci /run/gradle
Avg response time of the 450 requests: 25.0074311111s
----
Fibonacci /test/gradle
Avg response time of the 60 requests:	28.1260166667s
----
Calculator /run/java
Avg response time of the 500 requests: 19.7726s
----
Calculator /test/java
Avg response time of the 500 requests:	21.496412s
