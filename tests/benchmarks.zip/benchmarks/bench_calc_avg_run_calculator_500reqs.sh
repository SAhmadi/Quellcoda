# This script will print the avg. response time
# of 500 successful requests from the ./run_calculator_500reqs directory

folder="run_calculator_500reqs"
total_calls=0
total_success=500
total_t=0
echo "Calc. avg from run_calculator_500reqs/ from $total_success successful requests..."

for file in ./${folder}/*
do
	if ((total_calls >= total_success)); then
		break
	fi

	unavailable=$(grep "Service Unavailable" "$file")
	unavailable_len=${#unavailable}
	error=$(grep "rror" "$file")
	error_len=${#error}

	if ((unavailable_len > 0)); then
		echo "Returned: Service Unavailable"
		continue
	fi

	if ((error_len > 0)); then
		echo "Returned Error: $error"
		continue
	fi

	total_calls=$((total_calls + 1))
		
	t=$(grep "real\\t" "$file")
	# Get time parts (assumeing max req time < 10min)
	t=${t:(-9)}
	t=${t:0:8}	# clear the s char
	
	idx=(-1)
	if [[ ${t:0:1} == 0 ]]; then
		idx=0
	else
		idx=1
	fi
	
	min=${t:$idx:1}
	min_to_sec=$((min * 60))
	total_t=$(python -c "import sys; print(float(sys.argv[1])+float(sys.argv[2]))" $total_t $min_to_sec)

	idx=$((idx + 2))
	sec=${t:$idx}
	total_t=$(python -c "import sys; print(float(sys.argv[1])+float(sys.argv[2]))" $total_t $sec)

	# Needed for manual plotting
	# min_and_sec=$(python -c "import sys; print(float(sys.argv[1])+float(sys.argv[2]))" $min_to_sec $sec)
	# echo $min_and_sec
done

avg=$(python -c "import sys; print(float(sys.argv[1]) / float(sys.argv[2]))" $total_t $total_success)
echo "Avg response time of the $total_calls requests:\\t${avg}s"
