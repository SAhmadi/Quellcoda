# This script will print the avg. response time
# of 450 successful requests from the ./run_hello_world_500reqs directory

folder="run_hello_world_500reqs"
total_calls=0
total_success=450
total_t=0
echo "Calc. avg from run_hello_world_500reqs/ from $total_success successful requests..."

for file in ./${folder}/*
do
	if ((total_calls >= total_success)); then
		break
	fi

	success=$(grep "BUILD SUCCESSFUL" "$file")
	success_len=${#success}
	if ((success_len > 0)); then
		total_calls=$((total_calls + 1))
		
		t=$(grep "real\\t" "$file")
		# Get time parts (assumeing max req time < 10min)
		t=${t:(-9)}
		t=${t:0:8}	# clear the s char
		
		idx=(-1)
		if [[ ${t:0:1} == 0 ]]; then
			idx=0
		else
			idx=1
		fi
		
		min=${t:$idx:1}
		min_to_sec=$((min * 60))
		total_t=$(python -c "import sys; print(float(sys.argv[1])+float(sys.argv[2]))" $total_t $min_to_sec)

		idx=$((idx + 2))
		sec=${t:$idx}
		total_t=$(python -c "import sys; print(float(sys.argv[1])+float(sys.argv[2]))" $total_t $sec)		
	fi
done

avg=$(python -c "import sys; print(float(sys.argv[1]) / float(sys.argv[2]))" $total_t $total_success)
echo "Avg response time of the $total_calls requests:\\t${avg}s"
