package com.example.project;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;


class BalisticTests {

	private void callTest(String[] params, double minusVal) {
		final ByteArrayOutputStream myOut = new ByteArrayOutputStream();
		System.setOut(new PrintStream(myOut));

		Balistic.main(params);
		final var stdout = myOut.toString();

		NumberFormat nf = NumberFormat.getNumberInstance(Locale.ENGLISH);
		nf.setMinimumFractionDigits(5);
		DecimalFormat df = (DecimalFormat) nf;
		df.setRoundingMode(RoundingMode.FLOOR);

		assertDoesNotThrow(() -> {Double.parseDouble(stdout);});
		double value = Double.parseDouble(
				df.format(Double.parseDouble(stdout))
		);
		assertTrue(value - minusVal < 0.0001);
	}

	@Test
	@DisplayName("Balistic 9.78033 0 1")
	public void test_1() {
		callTest(new String[]{"9.78033", "0", "1"}, 4.89016);
	}

	@Test
	@DisplayName("Balistic 0 100 1")
	public void test_2() {
		callTest(new String[]{"0", "100", "1"}, 95.10983);
	}

	@Test
	@DisplayName("Balistic 0 100 2")
	public void test_3() {
		callTest(new String[]{"0", "100", "2"}, 180.43934);
	}

	@Test
	@DisplayName("Balistic 0 100 3")
	public void test_4() {
		callTest(new String[]{"0", "100", "3"}, 255.98851);
	}

	@Test
	@DisplayName("Balistic 0 10 3.5")
	public void test_5() {
		callTest(new String[]{"0", "10", "3.5"}, (-24.90452));
	}
}
